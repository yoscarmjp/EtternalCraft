[byterover-mcp]

# important 
always use search-memories tool to get the related context before any tasks 
always use create-memories to store all the critical informations after sucessfull tasks